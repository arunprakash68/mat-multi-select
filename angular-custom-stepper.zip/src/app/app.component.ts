import { Component, ViewChild, ElementRef } from '@angular/core';
import { StepperComponent } from './stepper/stepper.component';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  name = 'Angular 6';
  show = false;
  counter = 1;
  counter2 = 1;
  nextStep() {
    // this.stepper.nextStep();
    this.counter++;
  }

  prevStep() {
    // this.stepper.prevStep();
    this.counter--;
  }

  setStep(step) {
    // this.stepperRef.setStep(step);
    this.counter = step;
  }

  nextStep2() {
    // this.stepper.nextStep();
    this.counter2++;
  }

  prevStep2() {
    // this.stepper.prevStep();
    this.counter2--;
  }

  setStep2(step) {
    // this.stepperRef.setStep(step);
    this.counter2 = step;
  }


}
