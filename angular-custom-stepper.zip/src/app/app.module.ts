import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { StepperComponent } from './stepper/stepper.component';
import { StepComponent } from './stepper/step/step.component';
import { StepperService } from './stepper/stepper.service';
import { IonicModule } from 'ionic-angular';

@NgModule({
  imports: [BrowserModule, FormsModule, IonicModule],
  declarations: [AppComponent, StepperComponent, StepComponent],
  bootstrap: [AppComponent],
  providers: []
})
export class AppModule { }
